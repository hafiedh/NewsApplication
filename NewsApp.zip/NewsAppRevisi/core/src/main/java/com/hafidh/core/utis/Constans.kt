package com.hafidh.core.utis

object Constans {
    const val BASE_URL = "https://newsapi.org/"
    const val EXTRA_DATA = "extra_data"
}