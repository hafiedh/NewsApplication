package com.hafidh.newsapp


import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
open class Application : Application()